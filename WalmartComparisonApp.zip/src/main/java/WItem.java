
//class to hold the item information
public class WItem {
    String itemID;
    String name;
    String salePrice;
    String category;
    String shortDesc;
    String longDesc;
    String thumbnailImage;
    String mediumImage;
    String largeImage;
    String productURL;
    String custRating;
    String numReviews;
    String availability;

    public WItem(String itemID, String name, String salePrice, String category, String shortDesc,
                 String longDesc, String thumbnailImage, String mediumImage, String largeImage,
                 String productURL, String custRating, String numReviews, String availability) {
        this.itemID = itemID;
        this.name = name;
        this.salePrice = salePrice;
        this.category = category;
        this.shortDesc = shortDesc;
        this.longDesc = longDesc;
        this.thumbnailImage = thumbnailImage;
        this.mediumImage = mediumImage;
        this.largeImage = largeImage;
        this.productURL = productURL;
        this.custRating = custRating;
        this.numReviews = numReviews;
        this.availability = availability;

    }

    public void print() {
        System.out.println("WItem\n" +
                "itemID: "+itemID+"\n"+
                "name: "+name+"\n"+
                "category: "+category+"\n"+
                "shortDesc: "+shortDesc+"\n"+
                "longDesc: "+longDesc+"\n"+
                "thumbnailImage: "+thumbnailImage+"\n"+
                "mediumImage: "+mediumImage+"\n"+
                "largeImage: "+largeImage+"\n"+
                "productURL: "+productURL+"\n"+
                "custRating: "+custRating+"\n"+
                "numReviews: "+numReviews+"\n"+
                "availability: "+availability+"\n");
    }

    //get methods
    public String getItemID()
    {return itemID;}
    public String getName()
    {return name;}
    public String getSalePrice()
    {return salePrice;}
    public String getCategory()
    {return category;}
    public String getShortDesc()
    {return shortDesc;}
    public String getLongDesc()
    {return longDesc;}
    public String getThumbnailImage()
    {return thumbnailImage;}
    public String getMediumImage()
    {return mediumImage;}
    public String getLargeImage()
    {return largeImage;}
    public String getProductURL()
    {return productURL;}
    public String getCustRating()
    {return custRating;}
    public String getNumReviews()
    {return numReviews;}
    public String getAvailability()
    {return availability;}

    //set methods
    public void setItemID(String itemID)
    {this.itemID = itemID;}
    public void setName(String name)
    {this.name = name;}
    public void setSalePrice(String salePrice)
    {this.salePrice = salePrice;}
    public void setCategory(String category)
    {this.category = category;}
    public void setShortDesc(String shortDesc)
    {this.shortDesc = shortDesc;}
    public void setLongDesc(String longDesc)
    {this.longDesc = longDesc;}
    public void setThumbnailImage(String thumbnailImage)
    {this.thumbnailImage = thumbnailImage;}
    public void setMediumImage(String mediumImage)
    {this.mediumImage = mediumImage;}
    public void setLargeImage(String largeImage)
    {this.largeImage = largeImage;}
    public void setProductURL(String productURL)
    {this.productURL = productURL;}
    public void setCustRating(String custRating)
    {this.custRating = custRating;}
    public void setNumReviews(String numReviews)
    {this.numReviews = numReviews;}
    public void setAvailability(String availability)
    {this.availability = availability;}

}


