import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Main {
    static Connection conn;
    static ResultSet rs;
    static Statement stmt;

    public static void main(String[] args){

        //format string for the website to scrape
        String urlString = getQueryWord();

        //create xml file from website
        try {
            toXMLfile(urlString);
        } catch (IOException e) {
            e.printStackTrace();
        }

        List<WItem> inventory = makeList("XMLfiles/Walmart"+getDate()+".xml");

        try {
            fillDatabase(inventory);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    //asks user for search word and returns the url string
    public static String getQueryWord(){
        /*
        //create a scanner and use it to get
        Scanner input = new Scanner(System.in);
        System.out.print("Please enter your search word or phrase: ");
        String queryString = input.next();

        //format string for the website to scrape
        String urlString = String.format(
                "http://api.walmartlabs.com/v1/search?query=%s&format=xml&apiKey=nz47py7zpfc3xs6pmhfszxdm",
                queryString);
        */



        String urlString ="http://api.walmartlabs.com/v1/search?query=ipod&format=xml&apiKey=nz47py7zpfc3xs6pmhfszxdm";
        return urlString;
    }

    //grabs the information from the given url and puts it into a properly formatted xml file.
    public static void toXMLfile(String website) throws IOException {
        URL urlIn = new URL(website);
        Path pathOut = Paths.get("XMLfiles/Walmart"+getDate()+".xml");
        Files.copy(urlIn.openStream(), pathOut, StandardCopyOption.REPLACE_EXISTING);
    }

    public static List<WItem> makeList(String fileName){
        //creat a new arraylist of Sections
        List<WItem> inventory = new ArrayList<>();

        //begin the inputfactory
        XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();

        try {
            WItem item = new WItem("","","","","","","","","","","","","");

            //create the eventreader
            XMLEventReader xmlEventReader = xmlInputFactory.createXMLEventReader(
                    new FileInputStream(fileName));

            //go through the file
            while (xmlEventReader.hasNext()) {
                XMLEvent xmlEvent = xmlEventReader.nextEvent();

                if(xmlEvent.isStartElement()){
                    //put the string event in the variable name
                    String event= xmlEvent.asStartElement().getName().getLocalPart();
                    String str;

                    //str = xmlEventReader.getElementText();
                    //System.out.println(event);

                    if(event.equals("itemId")){
                        item = new WItem(null,null,null,null,null, null, null, null, null, null, null, null, null);
                        item.setItemID(xmlEventReader.getElementText());
                    }else if(event.equals("name")){
                        item.setName(xmlEventReader.getElementText());
                    }else if(event.equals("salePrice")){
                        item.setSalePrice(xmlEventReader.getElementText());
                    }else if(event.equals("categoryPath")){
                        item.setCategory(xmlEventReader.getElementText());
                    }else if(event.equals("shortDescription")){
                        item.setShortDesc(xmlEventReader.getElementText());
                    }else if(event.equals("longDescription")){
                        item.setLongDesc(xmlEventReader.getElementText());
                    }else if(event.equals("thumbnailImage")){
                        if(item.getThumbnailImage() == null) {
                            item.setThumbnailImage(xmlEventReader.getElementText());
                        }else{continue;}
                    }else if(event.equals("mediumImage")){
                        if(item.getMediumImage() == null) {
                            item.setMediumImage(xmlEventReader.getElementText());
                        }else {continue;}
                    }else if(event.equals("largeImage")){
                        if(item.getLargeImage() == null) {
                            item.setLargeImage(xmlEventReader.getElementText());
                        }else {continue;}
                    }else if(event.equals("productUrl")){
                        item.setProductURL(xmlEventReader.getElementText());
                    }else if(event.equals("customerRating")){
                        item.setCustRating(xmlEventReader.getElementText());
                    }else if(event.equals("numReviews")){
                        item.setNumReviews(xmlEventReader.getElementText());
                    }else if(event.equals("stock")){
                        item.setAvailability(xmlEventReader.getElementText());
                        inventory.add(item);
                    }
                }//end of if
            }//end of while
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (XMLStreamException e) {
            e.printStackTrace();
        }

        return inventory;
    }

    public static void fillDatabase(List<WItem> inventory) throws IOException, SQLException {
        //create sqlite connection to the database
        Sqlite db = new Sqlite();
        db.makeConnection("WalmartDB.db");
        db.clear("inventory");

        for(WItem item: inventory) {
            db.insert("inventory",
                    item.getItemID(), item.getName(), item.getSalePrice(), item.getCategory(), item.getShortDesc(),
                    item.getLongDesc(), item.getThumbnailImage(), item.getMediumImage(), item.getLargeImage(),
                    item.getProductURL(), item.getCustRating(), item.getNumReviews(), item.getAvailability());
        }

        db.close();
    }










    //get the current date for the output filename
    public static String getDate(){
        //get the current date for the output filename
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime now = LocalDateTime.now();
        String date = now.format(dtf);

        return date;
    }
}

//class to hold the item information
class WItem {
    String itemID;
    String name;
    String salePrice;
    String category;
    String shortDesc;
    String longDesc;
    String thumbnailImage;
    String mediumImage;
    String largeImage;
    String productURL;
    String custRating;
    String numReviews;
    String availability;

    public WItem(String itemID, String name, String salePrice, String category, String shortDesc,
                 String longDesc, String thumbnailImage, String mediumImage, String largeImage,
                 String productURL, String custRating, String numReviews, String availability) {
        this.itemID = itemID;
        this.name = name;
        this.salePrice = salePrice;
        this.category = category;
        this.shortDesc = shortDesc;
        this.longDesc = longDesc;
        this.thumbnailImage = thumbnailImage;
        this.mediumImage = mediumImage;
        this.largeImage = largeImage;
        this.productURL = productURL;
        this.custRating = custRating;
        this.numReviews = numReviews;
        this.availability = availability;

    }

    public void print() {
        System.out.println("WItem\n" +
                "itemID: "+itemID+"\n"+
                "name: "+name+"\n"+
                "category: "+category+"\n"+
                "shortDesc: "+shortDesc+"\n"+
                "longDesc: "+longDesc+"\n"+
                "thumbnailImage: "+thumbnailImage+"\n"+
                "mediumImage: "+mediumImage+"\n"+
                "largeImage: "+largeImage+"\n"+
                "productURL: "+productURL+"\n"+
                "custRating: "+custRating+"\n"+
                "numReviews: "+numReviews+"\n"+
                "availability: "+availability+"\n");
    }

    //get methods
    public String getItemID()
    {return itemID;}
    public String getName()
    {return name;}
    public String getSalePrice()
    {return salePrice;}
    public String getCategory()
    {return category;}
    public String getShortDesc()
    {return shortDesc;}
    public String getLongDesc()
    {return longDesc;}
    public String getThumbnailImage()
    {return thumbnailImage;}
    public String getMediumImage()
    {return mediumImage;}
    public String getLargeImage()
    {return largeImage;}
    public String getProductURL()
    {return productURL;}
    public String getCustRating()
    {return custRating;}
    public String getNumReviews()
    {return numReviews;}
    public String getAvailability()
    {return availability;}

    //set methods
    public void setItemID(String itemID)
    {this.itemID = itemID;}
    public void setName(String name)
    {this.name = name;}
    public void setSalePrice(String salePrice)
    {this.salePrice = salePrice;}
    public void setCategory(String category)
    {this.category = category;}
    public void setShortDesc(String shortDesc)
    {this.shortDesc = shortDesc;}
    public void setLongDesc(String longDesc)
    {this.longDesc = longDesc;}
    public void setThumbnailImage(String thumbnailImage)
    {this.thumbnailImage = thumbnailImage;}
    public void setMediumImage(String mediumImage)
    {this.mediumImage = mediumImage;}
    public void setLargeImage(String largeImage)
    {this.largeImage = largeImage;}
    public void setProductURL(String productURL)
    {this.productURL = productURL;}
    public void setCustRating(String custRating)
    {this.custRating = custRating;}
    public void setNumReviews(String numReviews)
    {this.numReviews = numReviews;}
    public void setAvailability(String availability)
    {this.availability = availability;}

}

class Sqlite {
    Connection conn;

    Sqlite() throws IOException {
    }

    //make initial connection to database
    //makes the initial connection to the database (Professor Noynaert's code)
    public boolean makeConnection(String fileName) {
        boolean successfullyOpened = false;

        String connectString = "jdbc:sqlite:" + fileName;
        try {
            conn = DriverManager.getConnection(connectString);
            if (conn != null) {
                successfullyOpened = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            successfullyOpened = false;
        }
        return successfullyOpened;
    }

    public void insert(String tableName, String itemID, String name, String salePrice, String category, String shortDesc,
                String longDesc, String thumbnailImage, String mediumImage, String largeImage,
                String productURL, String custRating, String numReviews, String availability) throws SQLException {
        //create statement
        Statement statement = conn.createStatement();

        //formats query string
        String queryString = String.format("insert into %s values (\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\");",
                tableName, itemID, name, salePrice, category, shortDesc, longDesc, thumbnailImage,
                mediumImage, largeImage, productURL, custRating, numReviews, availability);

        //execute and close the statement
        statement.executeUpdate(queryString);
        statement.close();
    }

    void clear(String tableName) {
        try {
            //create a statement
            Statement stmt = conn.createStatement();

            //formats the string to be able to execute the query successfully
            String queryString = String.format
                    ("DELETE FROM %s;", tableName);

            //executes the query and then closes the statement
            stmt.executeUpdate(queryString);
            stmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //close the connection
    public void close() {
        try {
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}